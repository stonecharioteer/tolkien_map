# tolkien_map
Static HTML Page which uses Leaflets, D3 and Bootstrap to render graphs on geospatial data.
